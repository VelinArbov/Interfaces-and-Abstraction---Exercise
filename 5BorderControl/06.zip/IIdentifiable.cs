﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _5BorderControl
{
    public interface IIdentifiable
    {

        string Birthdate { get; }
    }
}
