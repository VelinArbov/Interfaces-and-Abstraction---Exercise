﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _5BorderControl
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            List<IIdentifiable> all = new List<IIdentifiable>();

            while (true)
            {
                string input = Console.ReadLine();
                if ( input == "End")
                {
                    break;
                }

                string[] tokens = input.Split();
                if ( tokens.Length == 5)
                {
                    all.Add(new Citizen(tokens[1], int.Parse(tokens[2]),tokens[3], tokens[4]));

                }
                else if ( tokens.Length == 3 && tokens[0] == "Pet")
                {
                    all.Add(new Pet(tokens[1], tokens[2]));
                }



            }

            string lastNumber = Console.ReadLine();

            var newList = all.Where(x => x.Birthdate.EndsWith(lastNumber))
                  .Select(x => x.Birthdate)
                  .ToList();
                    //.ForEach(Console.WriteLine);
            if (newList.Count>0)
            {
                newList.ForEach(Console.WriteLine);
            }
            
            else
            {
              //  Console.WriteLine("<empty output>");
            }
        }
    }
}
