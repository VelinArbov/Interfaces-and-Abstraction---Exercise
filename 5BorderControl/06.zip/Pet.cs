﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _5BorderControl
{
   public class Pet : IIdentifiable
    {
        private string name;
        private int age;
        public Pet(string name, string birthdate)
        {
           
            this.name = name;
            this.Birthdate = birthdate;
        }







        public string Birthdate { get; private set; }
    }
}
