﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03Ferrari
{
    public interface IFerrari
    {

        string Name { get; }

    }
}
