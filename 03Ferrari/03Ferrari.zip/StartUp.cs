﻿using System;

namespace _03Ferrari
{
    class StartUp
    {
        static void Main(string[] args)
        {
            string name = Console.ReadLine();
            var driver = new Driver(name);
            Console.WriteLine(driver);
        }
    }
}
