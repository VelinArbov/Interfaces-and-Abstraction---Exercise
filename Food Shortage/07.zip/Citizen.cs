﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Food_Shortage
{
    public class Citizen : IBuyer
    {
        private string name;
        private int age;
        private string id;
        private DateTime birthday;
        private int food = 0;

        public Citizen(string name, int age, string id, string birthday)
        {
            this.Name = name;
            this.age = age;
            this.id = id;
            this.birthday = DateTime.ParseExact(birthday, "dd/mm/yyyy", null);

        }

        public int Food { get; private set; }

        public string Name { get; private set; }

        public void BuyFood()
        {
            Food += 10;
        }
    }
}
