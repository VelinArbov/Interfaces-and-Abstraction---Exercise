﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonInfo
{
    public class Citizen : IPerson
    {
        public Citizen(string name, int age)
        {
            this.Age = age;
            this.Name = name;
        }



        public string Name { get; private set; }

        public int Age { get; private set; }
    }
}
